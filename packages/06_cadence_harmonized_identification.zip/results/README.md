# Cadence-Harmonized Identification Check — v1

This package rebuilds the extensive-margin player-team-game outcome from the upstream common-time NBA injury-report snapshots rather than substituting a timestamp into the already-built final panel.

## Frozen common-time selection
The project’s canonical harmonized selector is used for all six seasons. These snapshots correspond to the common 1:30 / 5:30 / 8:30 ET reporting checkpoints (historical filenames use tokens such as `01PM`, `05PM`, and `08PM`). The 2025-26 mixed hourly/quarter-hour regime is handled with the previously built targeted common-time archive.

## Rebuild logic
1. Start from the official NBA boxscore roster denominator (248,571 rows).
2. Select the harmonized pre-tip injury-report snapshot for every game.
3. Parse report rows and resolve player identities using the frozen crosswalk plus the original reviewed alias fallbacks.
4. Add harmonized-snapshot report-only players.
5. Recompute absence status, prior workload, consecutive roster observation, at-risk status, and new absence onsets.
6. Re-estimate the player + team-season FE LPM with the same controls and player + game clustered standard errors.

## QA
- 7,230 games retained.
- 72,695 selected report player rows.
- 0 unresolved report player rows after reviewed fallbacks.
- 207 report-only player-team-game additions under the harmonized cadence.
- 248,778 full player-team-game rows.
- 180,664 at-risk rows; 12,731 new absence onsets.
- 5,420 / 7,230 games (74.97%) select a different report than the latest-pre-tip design, as expected because the common-time robustness intentionally uses earlier standardized checkpoints.

## Main result
Using player + team-season fixed effects, full controls, and player + game clustering:

- Legacy advance national-TV definition: +2.63 pp, 95% CI [+0.05, +5.22], p=0.0461 (N=180,530).
- Harmonized linear national-TV definition: +1.24 pp, 95% CI [-1.35, +3.82], p=0.3475 (N=180,530).

For comparison, under the latest-pre-tip outcome construction the corresponding estimates were +3.15 pp (p=0.0167) and +1.77 pp (p=0.1766).

Additional cadence-specific sensitivity:
- Excluding 2025-26: +2.18 pp, p=0.1102. (Legacy and harmonized-linear TV coincide over the remaining seasons under the current network definitions.)
- Excluding both 2020-21 and 2021-22: legacy +3.68 pp, p=0.0268; harmonized-linear +2.24 pp, p=0.1979.

## Interpretation / freeze decision
The extensive-margin association remains positive, but the evidence is not invariant to measurement choices. It weakens when both report cadence and national-TV exposure are harmonized, and the cadence-harmonized estimate excluding 2025-26 is not statistically distinguishable from zero. The result should therefore be described as measurement-sensitive rather than as a robust causal PPP effect at this stage.
