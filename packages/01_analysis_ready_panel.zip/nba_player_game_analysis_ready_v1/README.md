# NBA Player-Game Analysis-Ready Panel — v1

This package supersedes the provisional-taxonomy model panel.

## Frozen taxonomy change

The official designation taxonomy now uses only official injury-report wording.
Boxscore non-playing reasons still help determine whether an absence occurred,
but they no longer determine whether the official label was specific, vague,
illness, rest, other non-injury, or unknown.

Frozen precedence:

1. explicit rest
2. illness / health-and-safety
3. other non-injury
4. specific injury
5. vague injury/management language
6. unknown

The v2 specific dictionary adds tendinopathy, inflammation, bursitis,
hyperextension, abrasions and meniscectomy. Blank or unusable official wording
is `unknown`, not inferred from boxscore text.

## Validation limitation

The 300-spell review was coded by the assistant at the user's request. It is
not independent human double-coding. The frozen rules reproduce that review by
construction. A genuinely independent second coder remains recommended before
publication.

## QA

- Full rows: 248,730
- At-risk rows: 180,829
- Absence spells: 13,723
- Missing frozen outcomes in model rows: 0
- Spell initial classifications changed from v1: 1,527
- Absence player-game classifications changed from v1: 6,085
- Primary interaction at-risk rows: 1,640
- Primary interaction absence onsets: 128
- Primary interaction vague onsets: 44

## Main model file

`player_game_panel_model_at_risk_analysis_ready.csv.gz`

Use:

- `absence_onset`
- `onset_type_frozen`
- `vague_onset_frozen`
- `specific_onset_frozen`
- `explicit_rest_onset_frozen`
- `other_absence_onset_frozen`

Use `player_team_game_id` as the unique row key.

## Preserved v1 fields

- `designation_class_provisional_v1`
- `onset_type_provisional_v1`
- `vague_onset_provisional_v1`

## Next analytical step

Freeze the regression specification before reading coefficient estimates:

1. extensive margin: new absence onset
2. classification margin: vague versus specific injury onset, conditional on
   an injury onset
3. multinomial robustness: plays, specific, vague, rest, other
4. primary interaction: Star × PostPPP × announced national TV
5. Cup and schedule/strength controls
6. player and season fixed effects, with player- and game-clustered inference
